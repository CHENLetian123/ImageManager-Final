# Deployment and Run Guide

ImageManager Final is designed as a cloud-deployed web application.

The verified cloud deployment uses:

* Frontend: Cloudflare Pages
* Backend: Railway
* Database: Aiven MySQL
* Image Storage: Cloudflare R2

The project can also be run locally for source code review and testing.

## 1. Public Deployment

Frontend:

```text
https://imagemanager-final.pages.dev/
```

Backend health check:

```text
https://imagemanager-final-production.up.railway.app/api/health
```

If the public frontend cannot be accessed, please try turning off VPN.

Demo account:

```text
Username: report_demo
Password: 123456
```

## 2. Local Requirements

Install:

* JDK 17 or later
* Node.js 18 or later
* MySQL 8 or compatible version

The backend uses the Maven Wrapper, so Maven does not need to be installed separately.

## 3. Local Database

Create a local MySQL database:

```sql
create database defaultdb default character set utf8mb4 collate utf8mb4_general_ci;
```

Then run:

```text
database/schema.sql
```

The default local backend configuration uses:

```text
DB_URL=jdbc:mysql://localhost:3306/defaultdb
DB_USERNAME=root
DB_PASSWORD=mysql1234
```

If your local MySQL password is different, set the environment variables before running the backend.

## 4. Run Backend Locally

```bat
cd backend
.\mvnw.cmd spring-boot:run
```

Check:

```text
http://localhost:8080/api/health
```

Expected result:

```json
{"status":"ok"}
```

In local mode, uploaded images are stored in a local folder instead of Cloudflare R2.

## 5. Run Frontend Locally

Create `frontend/.env` if it does not exist:

```text
VITE_API_BASE_URL=http://localhost:8080
```

Then run:

```bat
cd frontend
npm install
npm run dev
```

Open:

```text
http://localhost:5173
```

## 6. Build Commands

Backend:

```bat
cd backend
.\mvnw.cmd clean package -DskipTests
```

Frontend:

```bat
cd frontend
npm install
npm run build
```
